# covid-calculator
COVID calculator for LAs
